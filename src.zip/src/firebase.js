import { initializeApp } from "firebase/app";
import { getAuth }       from "firebase/auth";
import { getDatabase }   from "firebase/database"
              
const firebaseConfig = {
  apiKey: "AIzaSyDPMisxy42g4t1rZJ-07OmJwW--sc7HN7o",
  authDomain: "signup-ddc98.firebaseapp.com",
  projectId: "signup-ddc98",
  storageBucket: "signup-ddc98.appspot.com",
  messagingSenderId: "899846874330",
  appId: "1:899846874330:web:df781971498da339f5f1e3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);


export const auth = getAuth(app);
export const db = getDatabase();
export default app;
