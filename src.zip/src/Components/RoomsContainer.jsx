import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Service() {
  const [data, setData] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);

  useEffect(() => {
    axios.get("http://localhost:4000/product")
      .then(res => setData(res.data))
      .catch(err => console.log(err));
  }, []);

  // A simple implementation of generateRandomId function
  const generateRandomId = () => {
    return Math.random().toString(36).substr(2, 9);
  };

  const handleBook = (item) => {
    setSelectedItem(item);
    const name = prompt("Please enter the name:");
    const checkInDate = prompt("Please enter your check-in date:");
    const checkOutDate = prompt("Please enter your check-out date:");
    const aadhar = prompt("please input the aadhar number");
    const userEmail = prompt("Please enter your email:");
    const idNumber = generateRandomId();
    alert(`Your booking Room ID: ${idNumber}`);
    if (checkInDate && checkOutDate && userEmail) {
      console.log(`Booking item: ${item.title}`);
      console.log(`Check-in date: ${checkInDate}`);
      console.log(`Check-out date: ${checkOutDate}`);
      console.log(`User email: ${userEmail}`);
    } else {
      console.log("Booking cancelled.");
    }
  };

  return (
    <div>
      <div>
        {data.map((x, i) => (
          i % 3 === 0 && (
            <div className="row" key={i}>
              {[data[i], data[i + 1], data[i + 2]].map((item, index) => (
                item && (
                  <div className="col" key={index}>
                    <div className='linear'>
                      <img src={item.image} width="100px" height="100px" alt={`Product ${i}`} />
                    </div>
                    <div className='lin1'>
                      <h1>{item.title}</h1>
                    </div>
                    <div className='lin2'>
                      <p>Price: {item.price}</p>
                    </div>
                    <div className='lin3'>
                      <p>Description: {item.description}</p>
                    </div>
                    <div className='lin4'>
                      <button onClick={() => handleBook(item)}>Book</button>
                    </div>
                  </div>
                )
              ))}
            </div>
          )
        ))}
      </div>
    </div>
  );
}
