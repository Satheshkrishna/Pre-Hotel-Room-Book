import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar';

export default function Product() {
  const [data, setData] = useState([]);
  const [image, setImage] = useState('');
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [des, setDes] = useState('');
  const [popup, setPopup] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    axios.get("http://localhost:4000/product")
      .then(res => setData(res.data))
      .catch(err => console.log(err));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:4000/product", {
        image,
        title,
        price,
        description: des
      });
      setData([...data, res.data]);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/product/${id}`);
      setData(data.filter(item => item.id !== id));
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:4000/product/${selectedProduct.id}`, {
        image: selectedProduct.image,
        title: selectedProduct.title,
        price: selectedProduct.price,
        description: selectedProduct.description
      });
      fetchData();
      setPopup(false);
    } catch (error) {
      console.error(error);
    }
  };

  const openPopup = (product) => {
    setSelectedProduct(product);
    setPopup(true);
  };

  return (
    <div>
      <Navbar />
      <div className='product'>
        <h1>Add products</h1>
        <form className='ko' onSubmit={handleSubmit}>
          <label>Images url: </label>
          <input type='text' value={image} onChange={(e) => setImage(e.target.value)} />
          <br /><br />
          <label>Title: </label>
          <input type='text' value={title} onChange={(e) => setTitle(e.target.value)} /><br /><br />
          <label>Price: </label>
          <input type='number' value={price} onChange={(e) => setPrice(e.target.value)} /><br /><br />
          <label>Description: </label>
          <input type='text' value={des} onChange={(e) => setDes(e.target.value)} /><br /><br />
          <button className='hon' type='submit'>Submit</button>
        </form>

        {popup && (
          <div className='ghost'>
            <form onSubmit={handleUpdate}>
              <button className="close" onClick={() => setPopup(false)}>X</button>
              <label>Images:</label>
              <input type='text' value={selectedProduct.image} onChange={(e) => setSelectedProduct({ ...selectedProduct, image: e.target.value })} />
              <br /><br></br>              <label>Title:</label>
              <input type='text' value={selectedProduct.title} onChange={(e) => setSelectedProduct({ ...selectedProduct, title: e.target.value })} />
              <br /><br></br>
              <label>Price:</label>
              <input type='number' value={selectedProduct.price} onChange={(e) => setSelectedProduct({ ...selectedProduct, price: e.target.value })} />
              <br /><br></br>
              <label>Description:</label>
              <input type='text' value={selectedProduct.description} onChange={(e) => setSelectedProduct({ ...selectedProduct, description: e.target.value })} />
              <br /><br></br><br></br>
              <button type='submit'>Submit</button><br></br>
            </form>
          </div>
        )}
      </div>
      <div className='left'>
        <table>
          <thead>
            <tr className='row'>
              <th>Images</th>
              <th>Title</th>
              <th>Price</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item) => (
              <tr className='row' key={item.id}>
                <td>
                  <img className="logo" src={item.image} width="100px" height="100px" alt={`Product ${item.id}`} />
                </td>
                <td>
                  <h4>{item.title}</h4>
                </td>
                <td>
                  <p>{item.price}</p>
                </td>
                <td>
                  <p>{item.description}</p>
                </td>
                <td>
                  <button className='btn1' onClick={() => openPopup(item)}>Update</button>
                  <button className="btn1" onClick={() => handleDelete(item.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
