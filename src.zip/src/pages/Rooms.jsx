import React from "react";
import Hero from "../Components/Hero";
import Banner from "../Components/Banner";
import { Link } from "react-router-dom";
import RoomsContainer from "../Components/RoomsContainer";
import './style.css';
const Rooms = () => {
  return (
    <div>
      <Hero hero="roomsHero"></Hero>
      <Banner title="Available Rooms Book" subtitle="Best Room in world">
      <h3>Login to Book Room</h3>
        <Link to="/signin" className="btn btn-warning">
          login
        </Link>
      </Banner>
      <div className="ol">
     <RoomsContainer/></div>
    </div>
  );
};

export default Rooms;
